
public class GenericInterfaceImpl implements GenericInterface<String,Integer>{

	@Override
	public Integer doOneOperation(Integer s) {
		
		return s;
	}

	@Override
	public String doSecondOperation(String t) {
		return t;
	}

}
