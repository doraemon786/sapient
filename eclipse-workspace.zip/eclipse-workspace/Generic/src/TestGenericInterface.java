
public class TestGenericInterface {

	public static void main(String[] args) {
		GenericInterfaceImpl g = new GenericInterfaceImpl();
		System.out.println(g.doOneOperation(100));
		System.out.println(g.doSecondOperation("Sachin"));
	}
}
