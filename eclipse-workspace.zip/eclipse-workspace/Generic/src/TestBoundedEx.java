
public class TestBoundedEx {
	
	public static void main(String[] args) {
		
		BoundedEx<ClassA>  a= new BoundedEx<ClassA>(new ClassA());
		BoundedEx<ClassA>  b= new BoundedEx<ClassA>(new ClassB());
		BoundedEx<ClassA>  c= new BoundedEx<ClassA>(new ClassC());
		a.runTest();
		b.runTest();
		c.runTest();
	}

}
