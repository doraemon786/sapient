
public class BoundedEx<T extends ClassA>{
	
	
private T  objeref;

public BoundedEx(T t) {
	this.objeref=t;
}

public void runTest()
{
	this.objeref.printClass();
}

}
