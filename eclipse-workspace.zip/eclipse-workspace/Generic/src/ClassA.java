
public class ClassA {

	
	public void printClass() {
		System.out.println("I am in Class A");
	}
}
