
public class GenericType<T> {
	
	private T t;

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}
	
	public static void main(String[] args) {
		
		GenericType<String> str= new GenericType<String>();
		str.setT("Amit");
        GenericType str1= new GenericType();   //Raw Type
        str1.setT("Amit");
        System.out.println(str1.getT());
        str1.setT(100);
        System.out.println(str1.getT());
	}

}
