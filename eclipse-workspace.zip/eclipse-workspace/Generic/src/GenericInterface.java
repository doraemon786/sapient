
public interface GenericInterface<T,S> {
	
	S doOneOperation(S s);
	T doSecondOperation(T t);

}
