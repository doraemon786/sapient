
public class ClassB extends ClassA{

	
	public void printClass() {
		System.out.println("I am in sub Class B");
	}
}


