package com.LambdaStreams;

public class LambdaDemo2 {

	@FunctionalInterface
	public static interface Converter<F, T> {
		T convert(F from);
	}

	static class Something {
		String startsWith(String s) {
			return String.valueOf(s.charAt(0));
		}

	}

	interface PersonFactory<P extends Person> {
		P create(String firstName, String lastName);
	}

	public static void main(String[] args) {
		Converter<String, Integer> intConverter1 = (from) -> Integer.valueOf(from);
		Integer converted1 = intConverter1.convert("1234");
		System.out.println(converted1);

		Converter<String, Integer> intConverter2 = Integer::valueOf;
		Integer converted2 = intConverter2.convert("123");
		System.out.println(converted2);

		Something something = new Something();
		Converter<String, String> strConvert = something::startsWith;
		String converted3 = strConvert.convert("Java in Full Swing");
		System.out.println(converted3);

		PersonFactory<Person> personFactory = Person::new;
		Person person = personFactory.create("Ameya", "Joshi");
		System.out.println(person);
	}
}
