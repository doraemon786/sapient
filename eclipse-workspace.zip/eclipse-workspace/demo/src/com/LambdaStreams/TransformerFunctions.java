package com.LambdaStreams;

import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TransformerFunctions {

	public static Student stringToStudent(String Student) {

		var datas = Student.split(" ");
		var studentObj = new Student();
		if (datas != null) {
			studentObj.setFirstName(datas[0]);
			studentObj.setLastName(datas[1]);
			studentObj.setAddress(datas[2]);
			studentObj.setCity(datas[3]);
			studentObj.setPercent(Double.parseDouble(datas[4]));
			System.out.println(studentObj);
		}
		return studentObj;
	}
	
/*	private static void studentToList() throws Exception {
		List<Student> studentsList = null;
		studentsList = Files.readString(Paths.get("sampledata.txt")).lines().map(TransformerFunctions::stringToStudent)
				.collect(Collectors.toList());
		System.out.println("	");

		System.out.println(studentsList);
	}
*/
	private static void testFind() throws Exception {
		Path start = Paths.get("");
		try (Stream<Path> stream = Files.find(start, 5, (path, attr) -> String.valueOf(path).endsWith(".txt"))) {
			String joined = stream.sorted().map(String::valueOf).collect(Collectors.joining(";"));
			System.out.println("find :: " + joined);
		}
	}

	private static void testReaderLines() throws Exception {
		Path path = Paths.get("sampledata.txt");
		try (BufferedReader reader = Files.newBufferedReader(path)) {
			long cnt = reader.lines().filter(line -> line.contains("kanpur")).count();
			System.out.println(cnt);
		}
	}


	public static void main(String args[]) throws Exception {
	//	studentToList();
		testFind();
		testReaderLines();

	}

	
}
