package com.LambdaStreams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class StreamDemo1 {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(2, 3, 4, 5);

		// finding square

		list.stream().map(x -> x * x).forEach(s -> System.out.println(s));

		// filter name
		List<String> name = Arrays.asList("Amit", "Ranjan", "Suresh");
		List<String> result = name.stream().filter(a -> a.startsWith("A")).collect(Collectors.toList());
		System.out.println(result);
		
		//sorted name
		List<String> sortedName=name.parallelStream().sorted().collect(Collectors.toList());
		System.out.println(sortedName);
		
		//sum of even number
		Integer sum=list.stream().filter(y->(y%2==0)).reduce(0,(ans,i)->ans+i);
		System.out.println(sum);
	}
}
