package com.LambdaStreams;


@FunctionalInterface
public interface GreetingService {

	
	void sayMessage(String message);
}
