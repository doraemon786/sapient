package com.LambdaStreams;

public class TestLambda {

	public static void main(String[] args) {

		MathOperation add = (a, b) -> a + b;
		MathOperation sub = (a, b) -> a - b;
		MathOperation mul = (a, b) -> a * b;
		MathOperation div = (a, b) -> a / b;

		System.out.println(add.operation(5, 6));
		System.out.println(sub.operation(5, 6));
		System.out.println(mul.operation(5, 6));
		System.out.println(div.operation(5, 6));

		GreetingService gs = new GreetingService() {

			@Override
			public void sayMessage(String message) {
				String uMsg = message.toUpperCase();
				System.out.println(uMsg);
			}
		};
		
		gs.sayMessage("Good Evening");
	}
}
