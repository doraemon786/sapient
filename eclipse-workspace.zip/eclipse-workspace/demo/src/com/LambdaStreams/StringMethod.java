package com.LambdaStreams;

import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class StringMethod {

	public static void main(String[] args) {
		testJoin();
		testPatterSplit();
		testChar();
	}

	private static void testChar() {
		String str = "foobar:foo:bar".chars().distinct().mapToObj(c -> String.valueOf((char) c)).sorted()
				.collect(Collectors.joining());
		System.out.println(str);

	}

	private static void testPatterSplit() {
		String str = Pattern.compile(":").splitAsStream("foobar:foo:bar").filter(s -> s.contains("bar")).sorted()
				.collect(Collectors.joining(":"));
		System.out.println(str);

	}

	// add : in string element
	private static void testJoin() {
		String str = String.join(":", "1", "2", "3");
		System.out.println(str);
	}
}
