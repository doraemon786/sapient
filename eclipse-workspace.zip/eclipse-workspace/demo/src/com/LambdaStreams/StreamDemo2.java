package com.LambdaStreams;

import java.util.ArrayList;
import java.util.List;

public class StreamDemo2 {

	public static void main(String[] args) {

		List<String> list = new ArrayList<String>();
		list.add("dd1");
		list.add("as1");
		list.add("we1");
		list.add("dd2");
		list.add("as2");

//get elemment start with a

		list.stream().filter(y -> y.startsWith("a")).forEach(a -> System.out.println(a));
		System.out.println();
		list.stream().filter(y -> y.startsWith("a")).forEach(System.out::print);

		System.out.println();
//upper case and sorted
		list.stream().sorted().map(a -> a.toUpperCase()).forEach(System.out::println);
	}
}
