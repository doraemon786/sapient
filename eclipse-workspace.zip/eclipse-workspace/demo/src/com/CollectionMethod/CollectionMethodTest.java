package com.CollectionMethod;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CollectionMethodTest {

	public static void main(String[] args) {
		
		
		List<String>  items= new ArrayList<String>();
		items.add("Apple");
		items.add("Mango");
		items.add("Tomato");
		
		Collections.addAll(items,"PineApple","CocoNut");
		System.out.println(items);
		Collections.sort(items,Collections.reverseOrder());
		System.out.println(items);
		Collections.sort(items);
		System.out.println(items);

		System.out.println(Collections.binarySearch(items,"PineApple"));
		
		List<String>   newList=new ArrayList<String>();
		newList.addAll(items);
		
		Collections.copy(newList,items);
		System.out.println(newList);
		
		
		List<String>   tempList=new ArrayList<String>();
		
		tempList=Arrays.asList("amit","sumit","deepak");
		items.forEach(System.out::println);
		System.out.println(Collections.disjoint(newList,tempList));
		
		items.forEach(System.out::println);
	}
}
