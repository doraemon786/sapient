package com.sourav.studentDriver;

import java.util.ArrayList;
import java.util.List;

import com.sourav.assignment.EnggStudent;
import com.sourav.assignment.ScienceStudent;
import com.sourav.assignment.Student;
import com.sourav.assignment.StudentUtility;
import com.sourav.assignment.StudentUtilityGenericArray;

public class TestStudent {

	public static void main(String[] args) {

		StudentUtility<Student> a = new StudentUtility<Student>(new ScienceStudent("Amit", 86.00, "2018"));
		StudentUtility<Student> b = new StudentUtility<Student>(new EnggStudent("Sachin", 719.00, "CSE"));

		System.out.println(a.compareStudent(b) + " Has high percentage");

		List<Student> studentList = new ArrayList<Student>();
		
		studentList.add(new Student("Amit", 45.00));
		studentList.add(new Student("Sunny", 67.00));
		studentList.add(new Student("Amit", 80.00));
		studentList.add(new Student("Surya", 57.00));
		/*StudentUtilityGenericArray  obj1= new StudentUtilityGenericArray();
		obj1.printAscending(studentList);
*/
	}
}
