package com.sourav.assignment;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public  class StudentUtilityGenericArray<T extends Student>  {
	private T t;

	public StudentUtilityGenericArray(T t) {

		this.t = t;
	}
	
	public double getPercentage() {
		return t.getPercent();
	}
	
	public String getName() {
		return t.getName();
	}

	public <T> void printAscending(List<T> studentList) {
		
		
	}



}
