package com.sourav.assignment5;

import com.sourav.customexception.MaxLengthExceededException;
import com.sourav.customexception.MaxValueExceededException;
import com.sourav.customexception.NegativeValueException;

public class Employee {

	private int id;
	private String name;
	private double salary;
	
	public Employee() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(int id, String name, double salary) throws NegativeValueException, MaxLengthExceededException, MaxValueExceededException {

		if(id>=0&&name!=null&&name.length()<30&&salary>0&&salary<=99999){
		this.id = id;
		this.name = name;
		this.salary = salary;
		}
		else if(id<0)
		{
			throw new NegativeValueException(id);
		}
		else if(name.length()>30)
		{
			throw new MaxLengthExceededException(name.length());
		}
		else if(salary>99999)
		{
			throw new MaxValueExceededException(salary);
		}
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
}
