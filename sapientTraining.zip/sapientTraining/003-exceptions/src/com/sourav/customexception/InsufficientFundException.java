package com.sourav.customexception;

public class InsufficientFundException extends Exception{
public InsufficientFundException(float amount,String actType) {
	
	System.out.println("insufficient funds in "+actType);
}
}
