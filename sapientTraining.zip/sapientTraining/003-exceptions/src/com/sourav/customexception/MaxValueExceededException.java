package com.sourav.customexception;

public class MaxValueExceededException extends Exception {

	public MaxValueExceededException(double amount) {

		System.out.println("Amount exceded limit of 99999,current value is " + amount);
	}
}
