package com.sourav.customexception;

public class StackEmptyException extends Exception {

	public StackEmptyException() {
		System.out.println("Stack is empty!! Please push first");
	}
}
