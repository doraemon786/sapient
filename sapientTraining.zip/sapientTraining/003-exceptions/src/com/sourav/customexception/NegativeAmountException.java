package com.sourav.customexception;

public class NegativeAmountException extends Exception {
	
	public NegativeAmountException(float amount) {
		
		System.out.println("Amount is negative");
	}

}
