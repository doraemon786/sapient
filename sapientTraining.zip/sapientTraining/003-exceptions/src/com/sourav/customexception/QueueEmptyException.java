package com.sourav.customexception;

public class QueueEmptyException extends Exception {

	public QueueEmptyException() {
		System.out.println("Queue is Empty !! Please insert first");
	}
}
