package com.sourav.customexception;

public class LowSalaryException extends Exception {

	
	public LowSalaryException(double basic) {

	System.out.println("Basic is less then 500 rs i.e "+basic);
	}
}
