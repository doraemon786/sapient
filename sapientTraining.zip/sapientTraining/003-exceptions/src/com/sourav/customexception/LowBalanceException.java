package com.sourav.customexception;

public class LowBalanceException extends Exception{

	public LowBalanceException(float amount,String actTyp) {
		
		System.out.println("Balance is low for account type "+actTyp);
	}
}
