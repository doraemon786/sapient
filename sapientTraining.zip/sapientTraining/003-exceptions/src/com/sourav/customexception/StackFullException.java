package com.sourav.customexception;

public class StackFullException extends Exception {

	
	public StackFullException() {
		
		System.out.println("Stack is full!! Please pop first to make space");
	}
}
