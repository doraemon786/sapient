package com.sourav.customexception;

public class NegativeValueException extends Exception {

	public NegativeValueException(int id) {

		System.out.println("ID Can not be negative,Provided value for id is" + id);
	}
}
