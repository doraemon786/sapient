package com.sourav.customexception;

public class MaxLengthExceededException extends Exception {

	public MaxLengthExceededException(double salary) {
		System.out.println("Name length can not be greater then 30 character,current lenght is " + salary);
	}
}
