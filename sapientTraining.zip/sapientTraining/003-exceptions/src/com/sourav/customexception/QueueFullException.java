package com.sourav.customexception;

public class QueueFullException extends Exception {

	public QueueFullException() {
		System.out.println("Queue is full !! Please empty first");
	}
}
