package com.sourav.assignment2;

import com.sourav.customexception.LowSalaryException;

public class Emp {

	private int empid;
	private String empName;
	private String designation;
	private double basic;
	private double hra;

	public Emp(int empid, String empName, String designation, double basic) throws LowSalaryException {
		if (basic < 500) {
			throw new LowSalaryException(basic);
		} else {
			this.empid = empid;
			this.empName = empName;
			this.designation = designation;
			this.basic = basic;
		}
	}

	public Emp() {
	}

	public void printDET() {
		System.out.println("Emp [empid=" + empid + ", empName=" + empName + ", designation=" + designation + ", basic=" + basic
				+ ", hra=" + hra + "]");
	}

	public void calculateHRA() {
		if (this.getDesignation().equals("Manager")) {
			this.setHra(0.1 * this.getBasic());
			System.out.println("HRA is " + this.getHra()+" and designation is "+this.getDesignation());
		} else if (this.designation.equals("Officer")) {
			this.setHra(0.12 * this.getBasic());
			System.out.println("HRA is " + this.getHra()+" and designation is "+this.getDesignation());
		} else if (this.designation.equals("CLERK")) {
			this.setHra(0.05 * this.getBasic());
			System.out.println("HRA is " + this.getHra()+" and designation is "+this.getDesignation());
		}
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) throws LowSalaryException {
		if (basic < 500) {
			throw new LowSalaryException(basic);
		} else {
			this.basic = basic;
		}
	}

	public double getHra() {
		return hra;
	}

	private void setHra(double hra) {
		this.hra = hra;
	}

}
