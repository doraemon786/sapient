package com.sourav.assignment1;

public class MyNumber {
	private int firstNumber;
	private int secondNumber;
	private double result;

	public MyNumber(int firstNumber, int secondNumber) {
		this.firstNumber = firstNumber;
		this.secondNumber = secondNumber;
	}

	public void add() {
		this.result = this.firstNumber + this.secondNumber;
		System.out.println("Sum is "+this.result);
	}

	public void sub() {
		this.result = this.firstNumber - this.secondNumber;
		System.out.println("difference is "+this.result);
	}

	public void mul() {
		this.result = this.firstNumber * this.secondNumber;
		System.out.println("Product is "+this.result);
	}

	public void div() {
		if(this.secondNumber>0||this.secondNumber<0){
		this.result = this.firstNumber / this.secondNumber;
		System.out.println("division is "+this.result);
		}
		else{
			throw new ArithmeticException("Divide by Zero not possible");
		}
	}

	public MyNumber() {
	}

	
}
