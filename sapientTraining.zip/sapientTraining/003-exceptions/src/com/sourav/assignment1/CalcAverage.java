package com.sourav.assignment1;

import java.util.Scanner;

public class CalcAverage {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Enter the number upto which avg need to be calculated");
			double n = sc.nextDouble();
			avgFirstN(n);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}

	private static void avgFirstN(double n) {

		double sum = 0;
		double avg = 0;
		int count = (int) n;
		if (n >= 00 && (n - Math.floor(n) == 0)) {
			while (n > 0) {
				sum = sum + n;
				n--;
			}
			avg = sum / count;
			System.out.println("Average of first " + count + " number is " + avg);
		} else {
			throw new IllegalArgumentException("Number is a not a natural number " + n);
		}
	}

}
