package com.sourav.assignment1;

import com.sourav.customexception.InsufficientFundException;
import com.sourav.customexception.LowBalanceException;
import com.sourav.customexception.NegativeAmountException;

public class BankAccount {

	private int acctNo;
	private String custName;
	private float balance;
	private String accType; 
	
	
	public BankAccount(int acctNo, String custName, float balance, String accType) {
		super();
		this.acctNo = acctNo;
		this.custName = custName;
		this.balance = balance;
		this.accType = accType;
	}

	public void deposit(float amount) throws NegativeAmountException
	{
		if(amount<0){
			throw new NegativeAmountException(amount);
		}
		this.balance=this.balance+amount;
		System.out.println("deposit Successful of amount "+amount + " and currrent balance is"+this.balance);
		
	}
	
	public void withdraw(float amount) throws InsufficientFundException, NegativeAmountException
	{
		if(this.accType.equals("Savings")&&amount>0){
			
			if((this.balance-amount)>=1000)
			{
				this.balance=this.balance-amount;
				System.out.println("Withdraw Successfull of amount "+amount + " and currrent balance is"+this.balance);
			}
			else{
				throw new InsufficientFundException(amount,this.accType);
			}
		}
		else if(this.accType.equals("Current")&&amount>0){
			
			if((this.balance-amount)>=5000)
			{
				this.balance=this.balance-amount;
				System.out.println("Withdraw Successful of amount "+amount + " and currrent balance is"+this.balance);
			}
			else{
				
				throw new InsufficientFundException(amount,this.accType);
			}
		}
         else{
        	 throw new NegativeAmountException(amount);
         }
	}
	
	public void  getBalance() throws LowBalanceException, NegativeAmountException{
		if(this.balance<1000&&this.accType.equals("Savings")&&this.balance>0)
		{
			throw new LowBalanceException(this.balance,this.accType);
		}
		else if(this.balance<5000&&this.accType.equals("Current")&&this.balance>0)
		{
			throw new LowBalanceException(this.balance,this.accType);
		}
		else if(this.balance<0)
		{
			throw new NegativeAmountException(this.balance);
		}
		
		System.out.println("Current balance for account no "+this.acctNo+" "+this.accType+" is "+this.balance);
	}
}
