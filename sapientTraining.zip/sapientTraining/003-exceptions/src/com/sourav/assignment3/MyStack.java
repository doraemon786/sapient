package com.sourav.assignment3;

import com.sourav.customexception.StackEmptyException;
import com.sourav.customexception.StackFullException;

public class MyStack {
	private int data[];
	private int top;
	private final int SIZE = 5;

	public MyStack() {
		data = new int[SIZE];
		for (int i = 0; i < data.length; i++) {
			data[i] = -1;
		}
		top = -1;
		System.out.println("++++ Stack Initialized For Size " + SIZE + " Elements");
		printStack();
	}

	public boolean isFull() {
		if (top == SIZE - 1) {
			return true;
		}
		return false;
	}

	public boolean isEmpty() {
		if (top == -1) {
			return true;
		}
		return false;
	}

	public void push(int element) throws StackFullException {
		if(isFull())
		{
		throw new StackFullException();
		}else{
		top += 1;
		data[top] = element;
		}
	}

	public int pop() throws StackEmptyException {
		if(isEmpty())
		{
			throw new StackEmptyException();
		}else{
		int element = data[top];
		data[top] = -1;
		top -= 1;
		return element;
		}
	}

	public int peek() {
		return data[top];
	}

	public void printStack() {
		for (int i : data) {
			System.out.print(i + " ");
		}
		System.out.println("	TOP -> " + top);
	}
	
}
