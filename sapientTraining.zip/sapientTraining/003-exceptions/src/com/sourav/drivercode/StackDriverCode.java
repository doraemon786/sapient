package com.sourav.drivercode;

import com.sourav.assignment3.MyStack;
import com.sourav.customexception.StackEmptyException;
import com.sourav.customexception.StackFullException;

public class StackDriverCode {
	public static void main(String[] args) {
		
	
	MyStack stck = new MyStack();
	int element = 10;
	while (!stck.isFull()) {
		try {
			stck.push(element);
			stck.printStack();
			element += 10;
		} catch (StackFullException e) {
			e.printStackTrace();
		}
		
	}
	System.out.println("++++ Stack Full ++++");
	while (!stck.isEmpty()) {
		
		try {
			element = stck.pop();
			stck.printStack();
		} catch (StackEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	System.out.println("++++ Stack Empty ++++");
}
}

