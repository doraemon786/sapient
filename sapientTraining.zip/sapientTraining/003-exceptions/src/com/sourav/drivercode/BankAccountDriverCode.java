package com.sourav.drivercode;

import com.sourav.assignment1.BankAccount;
import com.sourav.customexception.InsufficientFundException;
import com.sourav.customexception.LowBalanceException;
import com.sourav.customexception.NegativeAmountException;

public class BankAccountDriverCode {
	
	public static void main(String[] args) {
		
		
		BankAccount  b1= new BankAccount(12123, "Anuj", 23000, "Savings");
		try {
			b1.deposit(2000);
			b1.withdraw(24001);
			b1.getBalance();
		} catch (NegativeAmountException | InsufficientFundException | LowBalanceException e) {
			e.printStackTrace();
		}
	}

}
