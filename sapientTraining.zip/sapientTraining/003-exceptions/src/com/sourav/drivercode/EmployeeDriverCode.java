package com.sourav.drivercode;

import com.sourav.assignment2.Emp;
import com.sourav.customexception.LowSalaryException;

public class EmployeeDriverCode {
	//Manager ,Officer, CLERK
	public static void main(String[] args) {
		
		try {
			Emp  e= new Emp(1, "Amit", "CLERK", 1000) ;
			e.calculateHRA();
			e.printDET();
			
		} catch (LowSalaryException e) {
			e.printStackTrace();
		}
	}

}
