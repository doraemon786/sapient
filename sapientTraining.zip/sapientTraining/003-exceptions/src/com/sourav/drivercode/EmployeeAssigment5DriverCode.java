package com.sourav.drivercode;

import com.sourav.assignment5.Employee;
import com.sourav.customexception.MaxLengthExceededException;
import com.sourav.customexception.MaxValueExceededException;
import com.sourav.customexception.NegativeValueException;

public class EmployeeAssigment5DriverCode {

	
	public static void main(String[] args) {
		try {
			Employee emp= new Employee(1, "qweq",2344000.00);
			System.out.println(emp.toString());
		} catch (NegativeValueException | MaxLengthExceededException | MaxValueExceededException e) {
			e.printStackTrace();
		}
	}
}
