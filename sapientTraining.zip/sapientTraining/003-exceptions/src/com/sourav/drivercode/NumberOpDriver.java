package com.sourav.drivercode;

import java.util.Scanner;

import com.sourav.assignment1.MyNumber;

public class NumberOpDriver {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the first number");
		int firstNumber=sc.nextInt();
		System.out.println("enter the second number");
		int secondNumber=sc.nextInt();
		
		MyNumber nb= new MyNumber(firstNumber,secondNumber);
		int choice;
		while(true){
			 System.out.println("Calculator Main Menu\n");
		        System.out.print("1.) Addition \n");
		        System.out.print("2.) Subtraction.\n");
		        System.out.print("3.) Multiplication.\n");
		        System.out.print("4.) Division.\n");
		        System.out.print("5.) Exit\n");
		        System.out.print("\nEnter Your Menu Choice: ");

		        choice = sc.nextInt();
		        switch(choice)
		        {
		        case 1:nb.add();
		        break;
		        case 2:nb.sub();
		        break;
		        case 3:nb.mul();
		        break;
		        case 4:nb.div();
		        break;
		        case 5:
		        	System.out.println("Exiting Program...");
		        	System.exit(0);
		        	break;
		        }
		}
		
	}
}
