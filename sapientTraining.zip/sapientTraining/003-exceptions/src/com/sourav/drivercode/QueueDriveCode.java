package com.sourav.drivercode;

import com.sourav.assignment4.LinearQueue;
import com.sourav.customexception.QueueEmptyException;
import com.sourav.customexception.QueueFullException;

public class QueueDriveCode {

	public static void main(String[] args) {

		LinearQueue lq = new LinearQueue(5);
		try {
			lq.insert(1);
			lq.insert(2);
			lq.insert(5);
			lq.insert(6);
			lq.insert(9);
			lq.insert(23);

		} catch (QueueFullException e) {
			e.printStackTrace();
		}
		lq.printStack();
		try {
			System.out.println("current queue size " + lq.delete());
			System.out.println("current queue size " + lq.delete());
			System.out.println("current queue size " + lq.delete());
			System.out.println("current queue size " + lq.delete());
			System.out.println("current queue size " + lq.delete());
			System.out.println("current queue size " + lq.delete());
		} catch (QueueEmptyException e) {
			e.printStackTrace();
		}
		lq.printStack();
		System.out.println("Element at front " + lq.peekQ());
	}
}
