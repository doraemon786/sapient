
public class TestInnerClass {
	public static void main(String[] args) {
		OuterClass obj = new OuterClass();
		obj.printOuterClassValue();

		// OuterClass.InnerClass obj1=new OuterClass().new InnerClass();
		OuterClass.InnerClass obj1 = new OuterClass.InnerClass();
		obj1.printValues();
	}

}
