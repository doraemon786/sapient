
public class OuterClass {

	int out_i = 10;

	public void printOuterClassValue() {
		System.out.println("Outer Class out_i :: " + out_i);
		System.out.println("InnerClass in_i :: " + new InnerClass().in_i);
	}

	public static class InnerClass {
		int in_i = 20;

		public void printValues() {
			System.out.println("InnerClass in_i :: " + in_i);
			System.out.println("OuterClass out_i :: " + new OuterClass().out_i);
		}
	}
}
