
public class TestStaticBlock {
	public static void main(String[] args) {

		System.out.println("This is the main method !!");

	}

	static {
		System.out.println("Static Block	!!");
		// System.exit(0);
	}

}
