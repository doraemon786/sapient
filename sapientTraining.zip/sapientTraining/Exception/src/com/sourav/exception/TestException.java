package com.sourav.exception;

import java.util.Scanner;

import com.sourav.customexception.MaxRangeExceededException;
import com.sourav.customexception.MinRangeExceededException;

public class TestException {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int a = Integer.parseInt(sc.nextLine());
		try {
			calculateFactorial(a);
		} catch (MinRangeExceededException | MaxRangeExceededException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		finally {
			sc.close();
			System.out.println("Resource has been closed");
		}
	}

	private static void calculateFactorial(int a) throws MinRangeExceededException, MaxRangeExceededException {

		int fact = 1;
		if (a == 0) {
			System.out.println("Factorial is " + 1);
		} else if (a < 0) {
			throw new MinRangeExceededException(a);
		} else if (a > 10) {
			throw new MaxRangeExceededException(a);
		} else {
			for (int i = a; i > 0; i--) {
				fact = fact * i;
			}
			System.out.println("factorial is " + fact);

		}
	}
}
