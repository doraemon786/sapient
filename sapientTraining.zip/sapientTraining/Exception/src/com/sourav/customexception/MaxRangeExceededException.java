package com.sourav.customexception;

public class MaxRangeExceededException extends Exception{
	
	public MaxRangeExceededException(int a) {
		
		System.out.println("Max Range Exceed exception");
	}

}
