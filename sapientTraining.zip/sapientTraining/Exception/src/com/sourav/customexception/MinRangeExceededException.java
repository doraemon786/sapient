package com.sourav.customexception;

public class MinRangeExceededException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MinRangeExceededException(int a) {
		System.out.println("Min Range Exception");
	}
	
	

}
