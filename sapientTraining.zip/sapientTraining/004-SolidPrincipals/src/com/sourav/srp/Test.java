package com.sourav.srp;

public class Test {

	public static void main(String[] args) {

		Customer c1 = new Customer("Shubham", "Junior eng");
		Customer c2 = new Customer("Anuj", "Senior eng");
		CustomerServiceImpl service = new CustomerServiceImpl();
		service.saveCustomer(c1);
		
		NotificationServiceImpl  notify= new NotificationServiceImpl();
		notify.sendNotification(new NotificationObject("Message sent"));
	}

}
