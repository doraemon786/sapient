package com.sourav.srp;

public class NotificationServiceImpl {

	private NotificationRepo notify;

	public NotificationServiceImpl(NotificationRepo notify) {
		super();
		this.notify = notify;
	}

	public void sendNotification(NotificationObject notificationObject)

	{
		notify.sendNotification(notificationObject);
		System.out.println("Notification sent..");

	}

	public NotificationServiceImpl() {
		notify = new NotificationRepo();
	}
}
