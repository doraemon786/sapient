package com.sourav.srp;

import java.util.ArrayList;
import java.util.List;

public class NotificationRepo {
	List<NotificationObject> notification = new ArrayList<NotificationObject>();

	public boolean sendNotification(NotificationObject notify) {
		this.notification.add(notify);
		
		return true;
	}
}
