package com.sourav.srp;

import java.util.ArrayList;
import java.util.List;

public class CustomerRepository {
	List<Customer> custList = new ArrayList<Customer>();

	public boolean saveCustomer(Customer cust) {
		this.custList.add(cust);
		System.out.println("Customer added..");
		
		return true;
	}

}
