package com.sourav.srp;

public class Customer {

	
	private String name;
	private String designation;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Customer(String name, String designation) {
		super();
		this.name = name;
		this.designation = designation;
	}
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
}
