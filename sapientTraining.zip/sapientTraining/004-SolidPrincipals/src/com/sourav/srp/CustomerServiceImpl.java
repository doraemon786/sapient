package com.sourav.srp;

public class CustomerServiceImpl {
	
	private CustomerRepository cusRepo;

	public CustomerServiceImpl(CustomerRepository cusRepo) {
		this.cusRepo = cusRepo;
	}
	
	public boolean saveCustomer(Customer Request)
	{
		return cusRepo.saveCustomer(Request);
	}
	public CustomerServiceImpl() {
		cusRepo= new CustomerRepository();
	}

}
