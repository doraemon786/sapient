package com.sourav.isp;

public class Worker implements IWorker,IRobot {

	@Override
	public void work() {
		System.out.println("worker working");
	}

	@Override
	public void eat() {
		System.out.println("worker eating");
	}

}
