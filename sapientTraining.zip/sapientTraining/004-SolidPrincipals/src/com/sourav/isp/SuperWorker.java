package com.sourav.isp;

public class SuperWorker implements IRobot{

	@Override
	public void work() {
		System.out.println("Robot working");
	}

}
