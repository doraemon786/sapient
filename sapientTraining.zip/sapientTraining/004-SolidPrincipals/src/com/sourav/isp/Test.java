package com.sourav.isp;

public class Test {

	public static void main(String[] args) {

		IWorker iw = new Worker();
		IRobot ir = new SuperWorker();
		iw.eat();
		iw.work();
		ir.work();
	}
}