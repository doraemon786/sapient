package com.sourav.isp;

public interface IRobot {
	public void work();
}
