package com.sourav.isp;

public interface IWorker extends IRobot{
	public void work();
	
	public void eat();
	

}
