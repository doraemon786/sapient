package com.sourav.lsp;

public class Crow implements FlyingBird{

	public void fly() {
		System.out.println("Crow Flies High in the sky");
	}

	@Override
	public void eat() {
		System.out.println("Crow eat");
		
	}
}
