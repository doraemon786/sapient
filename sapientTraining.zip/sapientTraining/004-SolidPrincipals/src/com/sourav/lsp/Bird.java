package com.sourav.lsp;

public interface Bird {
    public void eat();
}
