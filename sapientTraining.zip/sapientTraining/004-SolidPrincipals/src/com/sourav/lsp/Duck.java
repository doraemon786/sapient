package com.sourav.lsp;

public class Duck implements Bird {

	@Override
	public void eat() {
		System.out.println("Duck eats but can not fly");
	}

}
