package com.sourav.lsp;

import java.util.ArrayList;
import java.util.List;

public class Test  {

public static void main(String[] args) {
	
	
	List<Bird>  list= new ArrayList<Bird>();
	
	list.add(new Crow());
	list.add(new Duck());
	
	birdEat(list);
}

public static void birdEat(List<Bird> b)
{
	for(Bird bird:b)
	{
		bird.eat();
	}
}
}
