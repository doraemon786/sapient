package com.sourav.lsp;

public interface FlyingBird extends Bird {

	public void fly();
}
