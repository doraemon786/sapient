package com.sourav.ocp;

import java.util.ArrayList;
import java.util.List;

public class TestShape {

	public static void main(String[] args) {
		Shape c = new Circle(5);
		Shape r = new Rectangle(2, 3);
		Shape s = new Square(5);
		List<Shape> shape = new ArrayList<Shape>();
		shape.add(c);
		shape.add(r);
		shape.add(s);
		for(Shape sp:shape){
		sp.calculateArea();
		}

	}
}
