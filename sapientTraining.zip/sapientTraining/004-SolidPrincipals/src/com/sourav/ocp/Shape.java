package com.sourav.ocp;

public abstract class Shape {
	
	public abstract void calculateArea();

}
