package com.sourav.ocp;

public class Square extends Shape {

	private int side;

	public Square() {
	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}

	public Square(int side) {
		super();
		this.side = side;
	}

	@Override
	public void calculateArea() {
		System.out.println("Area of square " + this.side * this.side);
	}

}
