package com.sourav.ocp;

public class Circle extends Shape {

	private int radius;

	public Circle() {
	}

	

	public int getRadius() {
		return radius;
	}



	public void setRadius(int radius) {
		this.radius = radius;
	}



	public Circle(int radius) {
		super();
		this.radius = radius;
	}



	@Override
	public void calculateArea() {
		System.out.println("Area of circle is "+3.14*this.radius*this.radius);
	}

	// getter and setter methods...

}
