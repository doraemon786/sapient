package com.sourav.client;

public class EmpClient {

	
	public static void main(String[] args) {
		
		
		
	}
}
