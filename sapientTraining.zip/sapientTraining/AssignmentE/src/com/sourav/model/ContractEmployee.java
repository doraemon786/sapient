package com.sourav.model;

import java.util.Date;

public class ContractEmployee extends Employee {

	private int dailyRate;
	private int term;

	public int getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(int dailyRate) {
		this.dailyRate = dailyRate;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public ContractEmployee(int id, String name, Date startDate, int dailyRate, int term) {
		super(id, name, startDate);
		this.dailyRate = dailyRate;
		this.term = term;
	}

}
