package com.sourav.model;

import java.util.Date;

public class PartTimeEmployee extends CompanyEmployee {
	
	private float hourlyRate;

	public float getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(float hourlyRate) {
		this.hourlyRate = hourlyRate;
	}

	public PartTimeEmployee(int id, String name, Date startDate, int vacation, float hourlyRate) {
		super(id, name, startDate, vacation);
		this.hourlyRate = hourlyRate;
	}

	
	

	
}
