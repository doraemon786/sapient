package com.sourav.model;

import java.util.Date;

public class CompanyEmployee extends Employee {
	
	private int vacation;

	public int getVacation() {
		return vacation;
	}

	public void setVacation(int vacation) {
		this.vacation = vacation;
	}

	public CompanyEmployee(int id, String name, Date startDate, int vacation) {
		super(id, name, startDate);
		this.vacation = vacation;
	}

	
	

}
