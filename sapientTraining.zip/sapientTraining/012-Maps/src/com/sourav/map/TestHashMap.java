package com.sourav.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class TestHashMap {

	public static void main(String[] args) {

		HashMap<Integer, String> map = new HashMap<Integer, String>();

		for (int i = 0; i < 10; i++) {
			map.putIfAbsent(i, "val" + i);
		}
		map.forEach((id, val) -> System.out.println(val));
		map.forEach((id, val) -> System.out.println(val));
		map.computeIfPresent(3, (num, val) -> val + num);

		System.out.println("---");
		System.out.println(map.get(3));
		System.out.println("----");
		map.forEach((id, val) -> System.out.println(val));
		System.out.println("--");

		System.out.println(map.getOrDefault(4, "NOT FOUND"));
		System.out.println("	");
		System.out.println(map.getOrDefault(11, "NOT FOUND"));

		System.out.println("---");
		map.merge(9, "val9", (value, newValue) -> value.concat("|" + newValue));
		System.out.println(map.get(9));

		System.out.println(" 	");
		map.computeIfPresent(9, (num, val) -> null);
		System.out.println(map.containsKey(9));
		System.out.println(" 	");
		map.forEach((id, val) -> System.out.println(val));
		
		//iterating
		 Iterator<Entry<Integer, String>> it= map.entrySet().iterator();
		 
		 while(it.hasNext())
		 {
			 Entry<Integer, String> a=it.next();
			 System.out.println(a);
		 }

	}
}
