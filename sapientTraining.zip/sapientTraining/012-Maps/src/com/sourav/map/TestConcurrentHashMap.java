package com.sourav.map;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TestConcurrentHashMap {

	public static void main(String[] args) {
		// Create ConcurrentHashMap object of Type<Integer,String>
		ConcurrentHashMap<Integer, String> chm = new ConcurrentHashMap<Integer, String>();
		// add key-value pairs to map
		chm.put(1, "Ameya");
		chm.put(2, "Avani");
		chm.put(3, "Kshiti");
		// add key-values using ConcurrentMap methods
		chm.putIfAbsent(4, "Amol");
		chm.putIfAbsent(5, "Mukesh");
		// not-inserted as key is already present
		chm.putIfAbsent(1, "Rajesh");
		// iterate using enhanced for loop
		for (Map.Entry<Integer, String> m : chm.entrySet()) {
			System.out.println("KEY : " + m.getKey() + " VALUE : " + m.getValue());
		}

	}

}
