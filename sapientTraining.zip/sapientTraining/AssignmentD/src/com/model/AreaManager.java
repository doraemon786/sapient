package com.model;

public class AreaManager extends Employee{

	private int areaCode;
	private String areaName;
	public int getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(int areaCode) {
		this.areaCode = areaCode;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public AreaManager(Long empid, String empName, double empSal, int areaCode, String areaName) {
		super(empid, empName, empSal);
		this.areaCode = areaCode;
		this.areaName = areaName;
	}
	@Override
	public String toString() {
		return "AreaManager [areaCode=" + areaCode + ", areaName=" + areaName + ", getEmpid()=" + getEmpid()
				+ ", getEmpName()=" + getEmpName() + ", getEmpSal()=" + getEmpSal() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

	


}
