package com.model;

public class Accountant extends Employee {

	private String bankName;
	private int companyAccountNo;

	public Accountant() {
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public int getCompanyAccountNo() {
		return companyAccountNo;
	}

	public void setCompanyAccountNo(int companyAccountNo) {
		this.companyAccountNo = companyAccountNo;
	}

	public Accountant(Long empid, String empName, double empSal, String bankName, int companyAccountNo) {
		super(empid, empName, empSal);
		this.bankName = bankName;
		this.companyAccountNo = companyAccountNo;
	}

	@Override
	public String toString() {
		return "Accountant [bankName=" + bankName + ", companyAccountNo=" + companyAccountNo + ", getEmpid()="
				+ getEmpid() + ", getEmpName()=" + getEmpName() + ", getEmpSal()=" + getEmpSal() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}


}
