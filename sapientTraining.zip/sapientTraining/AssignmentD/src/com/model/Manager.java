package com.model;

public class Manager extends Employee {

	private Long cellno;

	public Manager() {
	}

	public Manager(Long empid, String empName, double empSal, Long cellno) {
		super(empid, empName, empSal);
		this.cellno = cellno;
	}

	public Long getCellno() {
		return cellno;
	}

	public void setCellno(Long cellno) {
		this.cellno = cellno;
	}

	@Override
	public String toString() {
		return "Manager [cellno=" + cellno + ", getEmpid()=" + getEmpid() + ", getEmpName()=" + getEmpName()
				+ ", getEmpSal()=" + getEmpSal() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}

	

}
