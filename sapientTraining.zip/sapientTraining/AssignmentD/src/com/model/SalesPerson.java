package com.model;

public class SalesPerson extends Employee {

	private double travellingAllowance;
	private double dearnessAllowance;
	public double getTravellingAllowance() {
		return travellingAllowance;
	}
	public void setTravellingAllowance(double travellingAllowance) {
		this.travellingAllowance = travellingAllowance;
	}
	public double getDearnessAllowance() {
		return dearnessAllowance;
	}
	public void setDearnessAllowance(double dearnessAllowance) {
		this.dearnessAllowance = dearnessAllowance;
	}
	public SalesPerson(Long empid, String empName, double empSal, double travellingAllowance,
			double dearnessAllowance) {
		super(empid, empName, empSal);
		this.travellingAllowance = travellingAllowance;
		this.dearnessAllowance = dearnessAllowance;
	}
	@Override
	public String toString() {
		return "SalesPerson [travellingAllowance=" + travellingAllowance + ", dearnessAllowance=" + dearnessAllowance
				+ ", getEmpid()=" + getEmpid() + ", getEmpName()=" + getEmpName() + ", getEmpSal()=" + getEmpSal()
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}
	
	
}
