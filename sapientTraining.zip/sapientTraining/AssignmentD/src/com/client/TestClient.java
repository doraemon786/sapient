package com.client;

import com.model.Accountant;
import com.model.AreaManager;
import com.model.Manager;
import com.model.SalesPerson;

public class TestClient {

	public static void main(String[] args) {

		Accountant acct = new Accountant(1L, "Sachin", 25000.00, "SBI", 2341);
		Manager m = new Manager(2L, "Amit", 40000.00, 132L);
		AreaManager am = new AreaManager(3L, "Anuj", 450000.00, 280, "Gurgaon");
		SalesPerson sp = new SalesPerson(3L, "Anuj", 450000.00, 1200.00, 100.00);
		System.out.println(acct.toString());
		System.out.println(m.toString());
		System.out.println(am.toString());
		System.out.println(sp.toString());

	}
}
