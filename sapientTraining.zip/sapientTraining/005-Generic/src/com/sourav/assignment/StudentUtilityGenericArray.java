package com.sourav.assignment;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StudentUtilityGenericArray {

	
	public  <T> void bubbleSort(T[] arr, Comparator<T> comp) {
		for (int i = arr.length - 1; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				if (comp.compare(arr[j], arr[j + 1]) > 0) {
					T temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
	}
	
}
