package com.sourav.assignment;

public class ScienceStudent extends Student {
	

	private String passingYear;

	public ScienceStudent(String name, double percent, String passingYear) {
		super(name, percent);
		this.passingYear = passingYear;
	}

	public String getPassingYear() {
		return passingYear;
	}

	public void setPassingYear(String passingYear) {
		this.passingYear = passingYear;
	}

	@Override
	public String toString() {
		return "ScienceStudent [passingYear=" + passingYear + "]";
	}

	

}
