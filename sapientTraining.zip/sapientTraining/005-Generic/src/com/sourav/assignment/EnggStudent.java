package com.sourav.assignment;

public class EnggStudent extends Student {
	

	private String stream;

	public EnggStudent(String name, double percent, String stream) {
		super(name, percent);
		this.stream = stream;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	@Override
	public String toString() {
		return "EnggStudent [stream=" + stream + "]";
	}

	
	
}
