package com.sourav.assignment;

public class StudentUtility<T extends Student> {

	private T t;

	public StudentUtility(T t) {

		this.t = t;
	}

	public double getPercentage() {
		return t.getPercent();
	}
	
	public String getName() {
		return t.getName();
	}

	public String compareStudent(StudentUtility<T> t1) {
		return t.getPercent() > t1.getPercentage() ? t.getName() : t1.getName();

	}
	
	

}
