package com.sourav.studentDriver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.sourav.assignment.EnggStudent;
import com.sourav.assignment.ScienceStudent;
import com.sourav.assignment.Student;
import com.sourav.assignment.StudentUtility;
import com.sourav.assignment.StudentUtilityGenericArray;

public class TestStudent {

	public static void main(String[] args) {

		StudentUtility<Student> a = new StudentUtility<Student>(new ScienceStudent("Amit", 86.00, "2018"));
		StudentUtility<Student> b = new StudentUtility<Student>(new EnggStudent("Sachin", 719.00, "CSE"));

		System.out.println(a.compareStudent(b) + " Has high percentage");

		ScienceStudent a1 = new ScienceStudent("Amit", 86.00, "2018");
		EnggStudent b1 = new EnggStudent("Sachin", 79.00, "CSE");
		ScienceStudent c1 = new ScienceStudent("Sumit", 56.00, "2019");
		EnggStudent d1 = new EnggStudent("Anand", 72.00, "CIVIL");
		Student[] studentArr = { a1, b1, c1, d1 };
		
		StudentUtilityGenericArray obj = new StudentUtilityGenericArray();
		  obj.bubbleSort(studentArr,new Comparator<Student>(){
	           (Student t1, Student t2) ->(t1.getPercent() < t2.getPercent())? 1:
	    t1.getPercent() > t2.getPercent() ? -1:0);
	              
	           
	       });
		
		  for(int i=0;i<studentArr.length;i++)
		  {
			  System.out.println(studentArr[i]);
		  }
		/*
		 * StudentUtilityGenericArray obj1= new StudentUtilityGenericArray();
		 * obj1.printAscending(studentList);
		 */
	}
}
