package com.sourav.stack;

public class Test {
	public static void main(String[] args) {
		MyStack stck = new MyStack();
		int element = 10;
		while (!stck.isFull()) {
			stck.push(element);
			stck.printStack();
			element += 10;
		}
		System.out.println("++++ Stack Full ++++");
		while (!stck.isEmpty()) {
			element = stck.pop();
			stck.printStack();
		}
		System.out.println("++++ Stack Empty ++++");
	}

}
