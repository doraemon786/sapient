package com.sourav.overloading;

public class OverloadedMethods {

	
	public void sum(int a,int b)
	{
		System.out.println("sum of two number"+(a+b));
	}
	
	public void sum(int a,int b,int c)
	{
		System.out.println("sum of three number"+(a+b+c));
	}
}
