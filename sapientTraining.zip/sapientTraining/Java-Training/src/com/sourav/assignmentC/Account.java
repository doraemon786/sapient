package com.sourav.assignmentC;

public class Account {

	private String acType;
	private double balance;

	public Account(String acType, double balance) {
		this.acType = acType;
		this.balance = balance;
	}

	public Account() {
	}

	public String getAcType() {
		return acType;
	}

	public void setAcType(String acType) {
		this.acType = acType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void withdraw(double amount)
	{
		if(this.balance<amount)
		{
			System.out.println("insufficient fund");
		}
		else
		{
			this.balance=this.balance-amount;
			System.out.println("Amount withdrawn "+amount);
			System.out.println("Current balance "+this.balance);
		}
	}
	public void deposit(double amount)
	{
		
			this.balance=this.balance+amount;
			System.out.println("Amount deposited "+amount);
			System.out.println("Current balance "+this.balance);
		
	}
	
	public void printAccountInfo()
	{
		System.out.println("Account [acType=" + acType + ", balance=" + balance + "]");
	}

	
}
