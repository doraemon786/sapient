package com.sourav.assignmentC;

public class AccountTest {

	public static void main(String[] args) {

		Account acc = new Account("Savings", 250000.00);
		acc.withdraw(5000.00);
		acc.deposit(2000.00);
		acc.printAccountInfo();

	}
}
