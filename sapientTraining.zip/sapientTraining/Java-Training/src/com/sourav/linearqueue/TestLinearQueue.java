package com.sourav.linearqueue;

public class TestLinearQueue {

	public static void main(String[] args) {

		LinearQueue lq = new LinearQueue(5);
		lq.insert(1);
		lq.insert(2);
		lq.insert(5);
		lq.insert(6);
		lq.insert(9);
		lq.insert(23);
		lq.printStack();
		System.out.println("current queue size "+lq.delete());
		lq.printStack();
		System.out.println("Element at front "+lq.peekQ());
	}

}
