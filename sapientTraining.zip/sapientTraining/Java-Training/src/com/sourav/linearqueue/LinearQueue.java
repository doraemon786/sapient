package com.sourav.linearqueue;

public class LinearQueue {
	private int data[];
	private int rear;
	private int front;
	private int SIZE;
	private int currentSize = 0;

	public LinearQueue(int size) {

		this.SIZE = size;
		front = 0;
		rear = -1;
		data = new int[SIZE];
	}

	public boolean isFull() {
		if (currentSize == SIZE) {
			return true;
		}
		return false;
	}

	public boolean isEmpty() {
		if (currentSize == 0) {
			return true;
		}
		return false;
	}

	public void insert(int item) {
		if (isFull()) {
			System.out.println("Queue is full");
		} else {
			rear++;
			if (rear == SIZE) {
				rear = 0;
			}
			data[rear] = item;
			currentSize++;
			System.out.println(item + " added to the queue");
		}

	}

	public int delete() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
		} else {
			front++;
			if (front == SIZE - 1) {
				System.out.println(data[front - 1] + " removed from the queue");
				front = 0;
			} else {
				System.out.println(data[front - 1] + " removed from the queue");
			}
			currentSize--;

		}
		return currentSize;
	}

	public int peekQ() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
		}
		return data[front];

	}

	public void printStack() {
		System.out.println("Printing queue");
		for (int i = front; i < data.length; i++) {
			System.out.print(" "+data[i]);

		}
		System.out.println();
	}
}
